"""Competitive Kaggriculture agent package."""
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
try:
    from .entrypoint import agent
except (ImportError, ValueError):
    from entrypoint import agent
__all__ = ['agent']
