"""Small defensive access helpers for Kaggle Struct and plain dictionaries."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
from typing import Any

def getv(obj: Any, key: str, default: Any=None) -> Any:
    """Read ``key`` from a dict-like object without assuming its concrete type."""
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    getter = getattr(obj, 'get', None)
    if callable(getter):
        try:
            return getter(key, default)
        except (AttributeError, KeyError, TypeError):
            pass
    return getattr(obj, key, default)

def as_int(value: Any, default: int=0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default

def as_float(value: Any, default: float=0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError, OverflowError):
        return default

def count_of(mapping: Any, key: str) -> int:
    return max(0, as_int(getv(mapping, key, 0), 0))
