"""Bounded deterministic unit-task assignment and action materialization."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
try:
    from .access import getv
except (ImportError, ValueError):
    from access import getv
try:
    from .constants import ANIMALS, CROPS, PRODUCTS
except (ImportError, ValueError):
    from constants import ANIMALS, CROPS, PRODUCTS
try:
    from .models import Task, UnitState
except (ImportError, ValueError):
    from models import Task, UnitState
try:
    from .routing import step_toward
except (ImportError, ValueError):
    from routing import step_toward
try:
    from .world import WorldState, manhattan
except (ImportError, ValueError):
    from world import WorldState, manhattan

def _has_products(unit: UnitState) -> bool:
    return any((unit.inventory.get(item, 0) > 0 for item in PRODUCTS))

def _feasible(unit: UnitState, task: Task, world: WorldState) -> bool:
    if task.kind == 'FEED':
        return unit.has('WHEAT')
    if task.kind == 'FERTILIZE':
        return unit.has('FERTILIZER')
    if task.kind == 'PLACE_ANIMAL':
        return unit.has(task.item)
    if task.kind == 'DROP':
        return _has_products(unit)
    if task.kind == 'PICKUP_ANIMAL':
        return world.shed.get(task.item, 0) > 0
    if task.kind == 'PICKUP_WHEAT':
        return world.shed.get('WHEAT', 0) > 0 and unit.inventory.get('WHEAT', 0) < task.quantity
    if task.kind == 'PICKUP_FERTILIZER':
        return world.shed.get('FERTILIZER', 0) > 0 and unit.inventory.get('FERTILIZER', 0) == 0
    return True

def _effective_target(unit: UnitState, task: Task, world: WorldState) -> tuple[int, int]:
    if task.kind.startswith('PICKUP_') or task.kind == 'DROP':
        return world.nearest_shed_access(unit.position)
    return task.target

def _action_for(unit: UnitState, task: Task, world: WorldState) -> list:
    target = _effective_target(unit, task, world)
    at_target = unit.position == target
    if task.kind.startswith('PICKUP_') or task.kind == 'DROP':
        at_target = world.is_shed_access(unit.position)
    if not at_target:
        return step_toward(unit.position, target)
    if task.kind == 'PLACE_ANIMAL':
        return ['PLACE', task.item]
    if task.kind == 'PICKUP_ANIMAL':
        return ['PICKUP', task.item, task.quantity]
    if task.kind == 'PICKUP_WHEAT':
        return ['PICKUP', 'WHEAT', task.quantity]
    if task.kind == 'PICKUP_FERTILIZER':
        return ['PICKUP', 'FERTILIZER', task.quantity]
    if task.kind == 'DROP':
        return ['DROP']
    if task.kind == 'PLANT':
        return ['PLANT', task.item]
    if task.kind in {'FEED', 'WATER', 'HARVEST', 'FERTILIZE', 'CARE', 'COLLECT_FERTILIZER', 'DIG', 'BUILD_COOP', 'BUILD_PASTURE'}:
        return [task.kind]
    return ['PASS']

def _fallback_action(unit: UnitState, world: WorldState) -> list:
    if world.day >= 29:
        if _has_products(unit):
            if world.is_shed_access(unit.position):
                return ['DROP']
            return step_toward(unit.position, world.nearest_shed_access(unit.position))
        return ['PASS']
    tile = world.tile_at(unit.position)
    if getv(tile, 'kind', '') == 'PLANT':
        if not bool(getv(tile, 'watered_today', False)) and world.day < 29:
            return ['WATER']
        crop = str(getv(tile, 'crop', ''))
        planted_day = int(getv(tile, 'planted_day', world.day) or world.day)
        mature = crop in CROPS and world.day - planted_day >= CROPS[crop]['first_yield_day']
        if int(getv(tile, 'yield_units', 0) or 0) > 0 and mature:
            return ['HARVEST']
    animal = str(getv(tile, 'animal', ''))
    if animal in ANIMALS:
        if not bool(getv(tile, 'fed_today', False)) and unit.has('WHEAT') and (world.day < 29):
            return ['FEED']
        if int(getv(tile, 'yield_units', 0) or 0) > 0:
            return ['HARVEST']
        if bool(getv(tile, 'fertilizer_available', False)):
            return ['COLLECT_FERTILIZER']
    return ['PASS']

def assign_actions(world: WorldState, tasks: list[Task]) -> list[list]:
    candidates: list[tuple] = []
    for unit in world.units:
        for task_index, task in enumerate(tasks):
            if not _feasible(unit, task, world):
                continue
            target = _effective_target(unit, task, world)
            candidates.append((task.priority, task.deadline, manhattan(unit.position, target), -task.value, task.stable_id, unit.index, task_index))
    candidates.sort()
    assigned_units: set[int] = set()
    assigned_tasks: set[int] = set()
    selected: dict[int, Task] = {}
    for *_, unit_index, task_index in candidates:
        if unit_index in assigned_units or task_index in assigned_tasks:
            continue
        assigned_units.add(unit_index)
        assigned_tasks.add(task_index)
        selected[unit_index] = tasks[task_index]
        if len(assigned_units) >= len(world.units):
            break
    actions: list[list] = []
    for unit in world.units:
        task = selected.get(unit.index)
        actions.append(_action_for(unit, task, world) if task else _fallback_action(unit, world))
    return actions
