"""Bounded strategic portfolio planner.

The planner intentionally exposes all high-impact choices as deterministic
functions so profiles can later be tuned by the champion/challenger harness.
"""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
import math
try:
    from .constants import ANIMALS, CROPS, LAND_PRICES, MARKET_PARAMS
except (ImportError, ValueError):
    from constants import ANIMALS, CROPS, LAND_PRICES, MARKET_PARAMS
try:
    from .market import daily_town_demand, demand_counts
except (ImportError, ValueError):
    from market import daily_town_demand, demand_counts
try:
    from .models import EconomicPlan
except (ImportError, ValueError):
    from models import EconomicPlan
try:
    from .world import WorldState
except (ImportError, ValueError):
    from world import WorldState
ANIMAL_DAILY_OUTPUT = {'GOOSE': 2.0, 'COW': 1.5, 'SHEEP': 4.0 / 3.0}
CROP_DAILY_OUTPUT = {crop: float(MARKET_PARAMS[crop]['T']) / (25.0 * 24.0) for crop in CROPS}

def _shared_daily_capacity(world: WorldState, item: str) -> float:
    """Town drain plus a bounded correction toward market equilibrium.

    Market headroom is a stock, not a recurring daily demand.  The bounded
    drift prevents long, slow price curves (notably Egg) from consuming the
    entire portfolio merely because their theoretical ceiling is distant.
    """
    params = MARKET_PARAMS[item]
    current = world.market_inventory.get(item, int(params['I0']))
    horizon = max(5.0, min(12.0, world.remaining_days))
    throughput_per_day = float(params['T']) / 24.0
    drift = (float(params['I0']) - current) / horizon
    drift = max(-throughput_per_day, min(throughput_per_day, drift))
    return max(0.0, daily_town_demand(world, item) + drift)

def _competitive_share(world: WorldState, shared_target: int, opponent: int) -> int:
    """Stable response around a fair share of shared market capacity."""
    if shared_target <= 0:
        return 0
    half = shared_target / 2.0
    response = half + 0.35 * (half - opponent)
    lower = int(math.ceil(0.3 * shared_target))
    upper = int(math.ceil(0.75 * shared_target))
    return max(lower, min(upper, int(math.ceil(response))))

def _animal_scores(world: WorldState) -> dict[str, float]:
    demand = demand_counts(world.shops)
    scores = {'GOOSE': 0.42 + 0.95 * demand['EGG'], 'COW': 1.12 + 0.78 * demand['MILK'], 'SHEEP': 1.18 + 1.05 * demand['WOOL']}
    for animal, data in ANIMALS.items():
        product = str(data['product'])
        price = world.market_prices.get(product, int(MARKET_PARAMS[product]['base']))
        base = int(MARKET_PARAMS[product]['base'])
        scarcity = max(0.6, min(1.8, price / max(1.0, base)))
        opponent_penalty = 1.0 / (1.0 + 0.06 * world.opponent_animals.get(animal, 0))
        scores[animal] *= scarcity * opponent_penalty
    return scores

def desired_animal_targets(world: WorldState) -> dict[str, int]:
    current = {animal: world.animal_count(animal) for animal in ANIMALS}
    if world.day == 0:
        goose_target = 0
        if demand_counts(world.shops).get('EGG', 0) > 0:
            goose_target = min(2, int(math.ceil(_shared_daily_capacity(world, 'EGG') / ANIMAL_DAILY_OUTPUT['GOOSE'])))
        return {'GOOSE': goose_target, 'COW': 3, 'SHEEP': 2}
    if world.day <= 2 or world.day > 18:
        return current
    targets: dict[str, int] = {}
    shop_demand = demand_counts(world.shops)
    for animal, data in ANIMALS.items():
        product = str(data['product'])
        if animal == 'GOOSE' and shop_demand.get('EGG', 0) <= 0:
            targets[animal] = current[animal]
            continue
        shared_target = int(math.ceil(_shared_daily_capacity(world, product) / ANIMAL_DAILY_OUTPUT[animal]))
        opponent = world.opponent_animals.get(animal, 0)
        targets[animal] = _competitive_share(world, shared_target, opponent)
    targets['COW'] = max(3, targets['COW'])
    targets['SHEEP'] = max(2, targets['SHEEP'])
    for animal in ANIMALS:
        targets[animal] = max(targets[animal], current[animal])
    growth_cap = 5 if world.day <= 5 else min(24, 5 + 2 * (world.day - 5))
    physical_cap = max(5, len(world.unlocked_quadrants) * 25 - 12)
    owned_capacity = min(growth_cap, physical_cap)
    scores = _animal_scores(world)
    opening_floor = {'GOOSE': current['GOOSE'], 'COW': max(3, current['COW']), 'SHEEP': max(2, current['SHEEP'])}
    while sum(targets.values()) > owned_capacity:
        removable = [name for name in ANIMALS if targets[name] > opening_floor[name]]
        if not removable:
            break
        animal = min(removable, key=lambda name: (scores[name], -targets[name], name))
        targets[animal] -= 1
    return targets

def desired_crop_targets(world: WorldState, animal_targets: dict[str, int]) -> dict[str, int]:
    demand = demand_counts(world.shops)
    animal_total = sum(animal_targets.values())
    targets = {crop: 0 for crop in CROPS}
    if world.day == 0:
        return {'WHEAT': 9, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 5}
    cutoffs = {'WHEAT': 25, 'CARROT': 26, 'TOMATO': 18, 'STRAWBERRY': 16, 'MELON': 17}
    for crop in CROPS:
        if world.day > cutoffs[crop]:
            continue
        if world.day < 5 and crop not in {'WHEAT', 'MELON'} and (demand.get(crop, 0) == 0):
            continue
        shared_target = int(math.ceil(_shared_daily_capacity(world, crop) / max(0.01, CROP_DAILY_OUTPUT[crop])))
        opponent = world.opponent_plants.get(crop, 0)
        targets[crop] = _competitive_share(world, shared_target, opponent)
    if world.day <= cutoffs['WHEAT']:
        feed_floor = min(40, int(math.ceil(1.35 * animal_total)) + 2)
        targets['WHEAT'] = max(targets['WHEAT'], feed_floor)
    max_crop_slots = max(0, len(world.unlocked_quadrants) * 25 - animal_total - 5)
    max_crop_slots = min(66, max_crop_slots)
    minimums = {crop: 0 for crop in CROPS}
    feed_floor = min(40, int(math.ceil(1.35 * animal_total)) + 2)
    minimums['WHEAT'] = min(targets['WHEAT'], feed_floor, max_crop_slots)
    while sum(targets.values()) > max_crop_slots:
        removable = [crop for crop, value in targets.items() if value > minimums[crop]]
        if not removable:
            break
        crop = min(removable, key=lambda name: (CROP_DAILY_OUTPUT[name] * float(MARKET_PARAMS[name]['base']) * (1.0 + 0.35 * demand.get(name, 0)) + 0.1 * CROP_DAILY_OUTPUT[name] * max(0, world.market_prices.get(name, 0) - int(MARKET_PARAMS[name]['base'])), -CROPS[name]['first_yield_day'], name))
        targets[crop] -= 1
    return targets

def desired_hands(world: WorldState, animal_targets: dict[str, int]) -> int:
    if world.hour >= 10:
        return world.hires_today
    schedule = {0: 5, 1: 4, 2: 5, 3: 5, 4: 5, 5: 5, 6: 8, 7: 8, 8: 9, 9: 10, 10: 11}
    return schedule.get(world.day, 12)

def _future_hire_cost(current: int, desired: int) -> int:
    a, b = (1, 1)
    costs: list[int] = []
    for _ in range(max(0, desired)):
        costs.append(a)
        a, b = (b, a + b)
    return sum(costs[max(0, current):max(0, desired)])

def _should_buy_land(world: WorldState, reserve_cash: int) -> bool:
    unlocked = len(world.unlocked_quadrants)
    if unlocked >= 3 or world.day >= 21:
        return False
    next_cost = LAND_PRICES[unlocked - 1]
    occupied = len(world.plants) + len(world.animals) + len(world.empty_structures) + len(world.weeds)
    if unlocked == 1:
        return world.day >= 4 and world.money >= next_cost + reserve_cash
    return world.day >= 7 and world.money >= next_cost + reserve_cash

def make_economic_plan(world: WorldState) -> EconomicPlan:
    animal_targets = desired_animal_targets(world)
    crop_targets = desired_crop_targets(world, animal_targets)
    current_animals = {animal: world.animal_count(animal) for animal in ANIMALS}
    feed_price = max(1, world.market_prices.get('WHEAT', 25))
    reserve_cash = max(250, int(sum(current_animals.values()) * feed_price * 1.25))
    buy_land = _should_buy_land(world, reserve_cash)
    unlocked = len(world.unlocked_quadrants)
    land_due = unlocked == 1 and world.day >= 4 or (unlocked == 2 and world.day >= 7)
    land_saving = unlocked == 1 and world.day >= 2 or (unlocked == 2 and world.day >= 5)
    hand_target = desired_hands(world, animal_targets)
    hire_reserve = _future_hire_cost(world.hires_today, hand_target)
    budget = int(world.money) - reserve_cash - hire_reserve
    if buy_land:
        budget -= LAND_PRICES[len(world.unlocked_quadrants) - 1]
    budget = max(0, budget)
    if land_due and (not buy_land):
        budget = 0
    elif land_saving and (not buy_land):
        next_land_cost = LAND_PRICES[unlocked - 1]
        budget = min(budget, max(0, int(world.money) - reserve_cash - hire_reserve - next_land_cost))
    animal_buys = {animal: 0 for animal in ANIMALS}
    if world.day <= 18:
        scores = _animal_scores(world)
        gaps = {animal: max(0, animal_targets[animal] - current_animals[animal]) for animal in ANIMALS}
        while budget > 0 and any(gaps.values()):
            candidates = [animal for animal, gap in gaps.items() if gap > 0]
            candidates.sort(key=lambda animal: (scores[animal] / ANIMALS[animal]['cost'], scores[animal], -ANIMALS[animal]['cost'], animal), reverse=True)
            bought = False
            for animal in candidates:
                cost = int(ANIMALS[animal]['cost'])
                if budget >= cost:
                    animal_buys[animal] += 1
                    gaps[animal] -= 1
                    budget -= cost
                    bought = True
                    break
            if not bought:
                break
    seed_buys = {crop: 0 for crop in CROPS}
    if world.day <= 26:
        demand = demand_counts(world.shops)
        crop_order = sorted(CROPS, key=lambda crop: (demand.get(crop, 0), world.market_prices.get(crop, MARKET_PARAMS[crop]['base']) / MARKET_PARAMS[crop]['base'], -CROPS[crop]['first_yield_day'], crop), reverse=True)
        for crop in crop_order:
            gap = max(0, crop_targets[crop] - world.crop_count(crop))
            cost = int(CROPS[crop]['seed'])
            quantity = min(gap, 10, budget // cost)
            if quantity > 0:
                seed_buys[crop] = quantity
                budget -= quantity * cost
    total_wheat = world.inventory_total('WHEAT')
    owned_animals = sum(current_animals.values())
    wheat_target = owned_animals * 2 + 2 if world.day <= 28 else 0
    if land_saving and (not buy_land):
        wheat_target = owned_animals
    wheat_gap = min(36, max(0, wheat_target - total_wheat))
    committed = sum((animal_buys[a] * int(ANIMALS[a]['cost']) for a in ANIMALS)) + sum((seed_buys[c] * int(CROPS[c]['seed']) for c in CROPS)) + hire_reserve + (LAND_PRICES[len(world.unlocked_quadrants) - 1] if buy_land else 0)
    feed_budget = max(0, int(world.money) - committed - 25)
    wheat_buy = min(wheat_gap, feed_budget // feed_price)
    remaining_reserve = max(25, reserve_cash - wheat_buy * feed_price)
    return EconomicPlan(animal_targets=animal_targets, crop_targets=crop_targets, animal_buys=animal_buys, seed_buys=seed_buys, wheat_buy=wheat_buy, desired_hands=hand_target, buy_land=buy_land, reserve_cash=remaining_reserve)
