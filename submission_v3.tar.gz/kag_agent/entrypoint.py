"""Public competition entry point."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
try:
    from .access import getv
except (ImportError, ValueError):
    from access import getv
try:
    from .assignment import assign_actions
except (ImportError, ValueError):
    from assignment import assign_actions
try:
    from .economy import make_economic_plan
except (ImportError, ValueError):
    from economy import make_economic_plan
try:
    from .orders import build_market_orders
except (ImportError, ValueError):
    from orders import build_market_orders
try:
    from .tasks import generate_tasks
except (ImportError, ValueError):
    from tasks import generate_tasks
try:
    from .validator import validate_action
except (ImportError, ValueError):
    from validator import validate_action
try:
    from .world import WorldState
except (ImportError, ValueError):
    from world import WorldState

def _safe_fallback(obs) -> dict:
    try:
        player = int(getv(obs, 'player', 0))
        farms = getv(obs, 'farms', []) or []
        farm = farms[player]
        hands = getv(farm, 'hands', []) or []
        farmer = ['PASS']
        position = getv(farm, 'farmer', [0, 0])
        tiles = getv(farm, 'tiles', []) or []
        if tiles and len(position) >= 2:
            x, y = (int(position[0]), int(position[1]))
            tile = tiles[y][x]
            if getv(tile, 'kind', '') == 'PLANT' and (not bool(getv(tile, 'watered_today', False))):
                farmer = ['WATER']
            elif int(getv(tile, 'yield_units', 0) or 0) > 0:
                farmer = ['HARVEST']
        return {'farmer': farmer, 'hands': [['PASS'] for _ in hands], 'market': []}
    except Exception:
        return {'farmer': ['PASS'], 'hands': [], 'market': []}

def decide(obs) -> dict:
    world = WorldState.from_observation(obs)
    plan = make_economic_plan(world)
    tasks = generate_tasks(world, plan)
    unit_actions = assign_actions(world, tasks)
    market_orders = build_market_orders(world, plan)
    return validate_action(world, unit_actions, market_orders)

def agent(obs) -> dict:
    try:
        return decide(obs)
    except Exception:
        return _safe_fallback(obs)
