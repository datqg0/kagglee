"""Pure market math and bounded marginal-sale decisions."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
import math
try:
    from .access import getv
except (ImportError, ValueError):
    from access import getv
try:
    from .constants import ANIMALS, HINGE_GAIN, MARKET_PARAMS, PRICE_FLOOR, SELL_RESERVE_FACTORS, SHED_CAPACITY, SHOPS
except (ImportError, ValueError):
    from constants import ANIMALS, HINGE_GAIN, MARKET_PARAMS, PRICE_FLOOR, SELL_RESERVE_FACTORS, SHED_CAPACITY, SHOPS
try:
    from .world import WorldState
except (ImportError, ValueError):
    from world import WorldState

def _shape(func: str, x: float, throughput: float | None=None) -> float:
    x = max(0.0, x)
    if func == 'linear':
        return x
    if func == 'sq':
        return x * x
    if func == 'sqrt':
        return math.sqrt(x)
    if func == 'log':
        return math.log1p(x)
    if func == 'log10':
        return math.log10(1.0 + x)
    if func == 'hinge':
        if not throughput or throughput <= 0:
            return x
        u = x / throughput
        return u + HINGE_GAIN * max(0.0, u - 1.0) ** 2
    return x

def market_price(item: str, inventory: int) -> int:
    params = MARKET_PARAMS[item]
    base = float(params['base'])
    equilibrium = int(params['I0'])
    throughput = float(params['T'])
    if inventory < equilibrium:
        func = str(params['below_func'])
        amplitude = float(params['below_target']) * base / _shape(func, throughput, throughput)
        price = base + amplitude * _shape(func, equilibrium - inventory, throughput)
    else:
        func = str(params['above_func'])
        amplitude = float(params['above_target']) * base / _shape(func, throughput, throughput)
        price = base - amplitude * _shape(func, inventory - equilibrium, throughput)
    return max(PRICE_FLOOR, int(round(price)))

def demand_counts(shops: tuple[str, ...]) -> dict[str, int]:
    demand = {item: 0 for item in MARKET_PARAMS}
    for shop in shops:
        products = SHOPS.get(shop, ())
        multiplier = 2 if len(products) == 1 else 1
        for item in products:
            demand[item] += multiplier
    return demand

def daily_town_demand(world: WorldState, item: str) -> float:
    """Exact average units/day removed by the town for a market item.

    The town centre removes one unit per day.  Shops run six times per day;
    single-product shops remove two units on each run.
    """
    centre = 0.0 if item == 'FERTILIZER' else 1.0
    return centre + 6.0 * demand_counts(world.shops).get(item, 0)

def profitable_inventory_ceiling(item: str, reserve_factor: float) -> int:
    """Largest market inventory whose quote remains above a reserve price.

    A bounded binary search keeps this exact for all engine price curves while
    avoiding a slow per-unit scan in the turn loop.
    """
    params = MARKET_PARAMS[item]
    equilibrium = int(params['I0'])
    threshold = max(PRICE_FLOOR + 1, int(round(float(params['base']) * reserve_factor)))
    throughput = max(1, int(math.ceil(float(params['T']))))
    low = equilibrium
    high = equilibrium + throughput
    hard_limit = equilibrium + 16 * throughput
    while high < hard_limit and market_price(item, high) >= threshold:
        low = high
        high = min(hard_limit, equilibrium + 2 * (high - equilibrium))
    if market_price(item, high) >= threshold:
        return high
    while low + 1 < high:
        middle = (low + high) // 2
        if market_price(item, middle) >= threshold:
            low = middle
        else:
            high = middle
    return low

def profitable_headroom(world: WorldState, item: str, reserve_factor: float) -> int:
    """Shared units the market can still absorb above ``reserve_factor``."""
    current = world.market_inventory.get(item, int(MARKET_PARAMS[item]['I0']))
    return max(0, profitable_inventory_ceiling(item, reserve_factor) - current)

def visible_opponent_supply(world: WorldState, item: str) -> int:
    if item in world.opponent_plants:
        return world.opponent_plants[item]
    product_to_animal = {'EGG': 'GOOSE', 'MILK': 'COW', 'WOOL': 'SHEEP'}
    animal = product_to_animal.get(item)
    return world.opponent_animals.get(animal, 0) if animal else 0

def marginal_sale_prices(item: str, inventory: int, quantity: int) -> list[int]:
    """Return the engine's pre-sale quote for each unit in a single-player estimate."""
    prices: list[int] = []
    current = inventory
    for _ in range(max(0, quantity)):
        price = market_price(item, current)
        prices.append(price)
        if price > PRICE_FLOOR:
            current += 1
    return prices

def choose_sale_quantity(world: WorldState, item: str, held: int) -> int:
    """Choose a bounded batch using marginal price, horizon, pressure and visible supply."""
    if held <= 0:
        return 0
    if world.day >= 28:
        return held
    keep = 0
    if item == 'WHEAT':
        unfed = sum((1 for located in world.animals if not bool(getv(located.tile, 'fed_today', False))))
        carried = sum((unit.inventory.get('WHEAT', 0) for unit in world.units))
        required_today = max(0, unfed - carried)
        pending_animals = sum((world.animal_count(animal) for animal in ANIMALS))
        unlocked = len(world.unlocked_quadrants)
        saving_for_land = unlocked == 1 and world.day >= 2 or (unlocked == 2 and world.day >= 5)
        feed_buffer = pending_animals if saving_for_land else 2 * pending_animals + 2
        keep = min(held, max(feed_buffer, required_today + pending_animals))
    if item == 'FERTILIZER' and world.day < 24:
        unlocked = len(world.unlocked_quadrants)
        saving_for_land = unlocked == 1 and world.day >= 2 or (unlocked == 2 and world.day >= 5)
        if not saving_for_land:
            keep = max(keep, min(4, held))
    sellable = max(0, held - keep)
    if sellable <= 0:
        return 0
    params = MARKET_PARAMS[item]
    base = int(params['base'])
    reserve_factor = SELL_RESERVE_FACTORS[item]
    if world.day >= 24:
        reserve_factor *= 0.5
    elif world.day >= 15:
        reserve_factor *= 0.72
    pressure = max(0.0, (world.shed_load - 65) / max(1.0, SHED_CAPACITY - 65))
    if pressure > 0:
        reserve_factor *= max(0.35, 1.0 - 0.55 * pressure)
    if world.money < max(200.0, len(world.animals) * 22.0):
        reserve_factor *= 0.75
    if visible_opponent_supply(world, item) >= 8:
        reserve_factor *= 0.86
    shop_demand = demand_counts(world.shops).get(item, 0)
    imminent_centre_drain = item != 'FERTILIZER' and world.step % 24 == 0
    if (shop_demand > 0 or imminent_centre_drain) and world.step % 4 == 0 and (pressure < 0.35) and (world.money >= max(250.0, len(world.animals) * 25.0)) and (world.day < 28):
        return 0
    if world.step % 4 == 1 and (shop_demand > 0 or imminent_centre_drain) and (world.day < 28) and (pressure < 0.6):
        reserve_factor *= 0.92
    reserve_price = max(2, int(round(base * reserve_factor)))
    if world.day < 15:
        batch_cap = 20
    elif world.day < 24:
        batch_cap = 32
    else:
        batch_cap = sellable
    batch_cap = min(sellable, batch_cap)
    inventory = world.market_inventory.get(item, int(params['I0']))
    quantity = 0
    for price in marginal_sale_prices(item, inventory, batch_cap):
        if price < reserve_price and pressure < 0.5:
            break
        quantity += 1
    return quantity
