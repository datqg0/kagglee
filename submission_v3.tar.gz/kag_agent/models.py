"""Lightweight records shared by the planner."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
from dataclasses import dataclass, field
from typing import Any
Position = tuple[int, int]

@dataclass(frozen=True, slots=True)
class UnitState:
    index: int
    position: Position
    inventory: dict[str, int]
    is_hand: bool = False

    def has(self, item: str, quantity: int=1) -> bool:
        return self.inventory.get(item, 0) >= quantity

@dataclass(frozen=True, slots=True)
class LocatedTile:
    position: Position
    tile: Any

@dataclass(frozen=True, slots=True)
class Task:
    kind: str
    target: Position
    priority: int
    deadline: int
    value: float = 0.0
    item: str = ''
    quantity: int = 1
    stable_id: str = ''

@dataclass(slots=True)
class EconomicPlan:
    animal_targets: dict[str, int] = field(default_factory=dict)
    crop_targets: dict[str, int] = field(default_factory=dict)
    animal_buys: dict[str, int] = field(default_factory=dict)
    seed_buys: dict[str, int] = field(default_factory=dict)
    wheat_buy: int = 0
    desired_hands: int = 0
    buy_land: bool = False
    reserve_cash: int = 0
