"""Market-order construction with a hard ten-order budget."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
try:
    from .constants import ANIMALS, CROPS, MAX_MARKET_ORDERS, MARKET_PARAMS, PRODUCTS
except (ImportError, ValueError):
    from constants import ANIMALS, CROPS, MAX_MARKET_ORDERS, MARKET_PARAMS, PRODUCTS
try:
    from .market import choose_sale_quantity
except (ImportError, ValueError):
    from market import choose_sale_quantity
try:
    from .models import EconomicPlan
except (ImportError, ValueError):
    from models import EconomicPlan
try:
    from .world import WorldState
except (ImportError, ValueError):
    from world import WorldState

def _hire_orders(world: WorldState, plan: EconomicPlan, available_slots: int) -> list[list]:
    if available_slots <= 0 or world.hour >= 10:
        return []
    missing = max(0, plan.desired_hands - world.hires_today)
    return [['HIRE'] for _ in range(min(missing, available_slots))]

def build_market_orders(world: WorldState, plan: EconomicPlan) -> list[list]:
    if world.day >= 29:
        liquidation = []
        for item in PRODUCTS:
            quantity = world.inventory_total(item)
            if quantity > 0:
                liquidation.append(['SELL', item, quantity])
        liquidation.sort(key=lambda order: (-(order[2] * world.market_prices.get(order[1], MARKET_PARAMS[order[1]]['base'])), order[1]))
        orders = liquidation[:MAX_MARKET_ORDERS]
        orders.extend(_hire_orders(world, plan, MAX_MARKET_ORDERS - len(orders)))
        return orders[:MAX_MARKET_ORDERS]
    sales: list[list] = []
    for item in PRODUCTS:
        if item == 'WHEAT' and plan.wheat_buy > 0:
            continue
        held = world.shed.get(item, 0)
        quantity = choose_sale_quantity(world, item, held)
        if quantity > 0:
            sales.append(['SELL', item, quantity])
    sales.sort(key=lambda order: (-(order[2] * world.market_prices.get(order[1], MARKET_PARAMS[order[1]]['base'])), order[1]))
    sales = sales[:7 if world.day >= 27 else 4]
    orders: list[list] = list(sales)
    if plan.wheat_buy > 0 and len(orders) < MAX_MARKET_ORDERS:
        orders.append(['BUY_PRODUCT', 'WHEAT', plan.wheat_buy])
    if plan.buy_land and len(orders) < MAX_MARKET_ORDERS:
        orders.append(['BUY_LAND'])
    for animal in sorted(ANIMALS, key=lambda name: (-plan.animal_buys.get(name, 0) * ANIMALS[name]['cost'], name)):
        quantity = plan.animal_buys.get(animal, 0)
        if quantity > 0 and len(orders) < MAX_MARKET_ORDERS:
            orders.append(['BUY_ANIMAL', animal, quantity])
    orders.extend(_hire_orders(world, plan, MAX_MARKET_ORDERS - len(orders)))
    for crop in sorted(CROPS, key=lambda name: (-plan.seed_buys.get(name, 0) * CROPS[name]['seed'], CROPS[name]['first_yield_day'], name)):
        quantity = plan.seed_buys.get(crop, 0)
        if quantity > 0 and len(orders) < MAX_MARKET_ORDERS:
            orders.append(['BUY_SEED', crop, quantity])
    return orders[:MAX_MARKET_ORDERS]
