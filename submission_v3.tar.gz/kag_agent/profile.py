"""Strategy profile hyperparameters and telemetry for V3."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
from dataclasses import dataclass, field
from typing import Any

@dataclass(slots=True)
class StrategyProfile:
    competitive_alpha: float = 0.3093
    competitive_min_share: float = 0.3093
    competitive_max_share: float = 0.7773
    labor_workload_divisor: float = 21.8006
    labor_max_hands: int = 14
    labor_safety_margin: float = 161.1257
    travel_cost_per_step: float = 6.8325
    feed_task_base: float = 42.4862
    water_task_base: float = 32.5345
    harvest_task_base: float = 41.008
    fertilize_task_base: float = 24.9602
    care_task_base: float = 21.9358
    place_animal_base: float = 54.3615
    build_base: float = 31.8494
    pickup_wheat_base: float = 41.5206
    pickup_fert_base: float = 21.4953
    drop_base: float = 51.5365
    max_multi_wheat: int = 4
    multi_carry_bonus: float = 16.2878
    reserve_factors: dict[str, float] = field(default_factory=lambda: {'WHEAT': 0.6441, 'CARROT': 0.5992, 'TOMATO': 0.5955, 'STRAWBERRY': 0.674, 'MELON': 0.6349, 'FERTILIZER': 0.3484, 'EGG': 0.5963, 'MILK': 0.6347, 'WOOL': 0.6422})
    front_run_tier1_opp: int = 3
    front_run_tier1_mult: float = 0.9004
    front_run_tier2_opp: int = 6
    front_run_tier2_mult: float = 0.8147
    land_day_1: int = 3
    land_day_2: int = 6
    land_day_3: int = 10
    animal_buy_cutoff: int = 17
    crop_cutoffs: dict[str, int] = field(default_factory=lambda: {'WHEAT': 25, 'CARROT': 26, 'TOMATO': 20, 'STRAWBERRY': 18, 'MELON': 18})
    care_cutoff_day: int = 27
    water_cutoff_day: int = 28
    terminal_liquidation_day: int = 28
DEFAULT_PROFILE = StrategyProfile()
PARAM_SPECS = [('competitive_alpha', float, 0.35, 0.05, 0.9), ('competitive_min_share', float, 0.28, 0.1, 0.5), ('competitive_max_share', float, 0.78, 0.5, 0.95), ('labor_workload_divisor', float, 20.0, 10.0, 40.0), ('labor_max_hands', int, 14, 8, 16), ('labor_safety_margin', float, 150.0, 50.0, 300.0), ('travel_cost_per_step', float, 6.0, 1.0, 15.0), ('feed_task_base', float, 40.0, 10.0, 80.0), ('water_task_base', float, 30.0, 10.0, 60.0), ('harvest_task_base', float, 45.0, 20.0, 90.0), ('fertilize_task_base', float, 25.0, 5.0, 50.0), ('care_task_base', float, 20.0, 5.0, 50.0), ('place_animal_base', float, 60.0, 20.0, 100.0), ('build_base', float, 35.0, 10.0, 70.0), ('pickup_wheat_base', float, 38.0, 15.0, 70.0), ('pickup_fert_base', float, 22.0, 10.0, 50.0), ('drop_base', float, 50.0, 20.0, 90.0), ('max_multi_wheat', int, 4, 2, 6), ('multi_carry_bonus', float, 15.0, 2.0, 30.0), ('front_run_tier1_opp', int, 3, 1, 5), ('front_run_tier1_mult', float, 0.9, 0.7, 0.99), ('front_run_tier2_opp', int, 6, 4, 10), ('front_run_tier2_mult', float, 0.82, 0.6, 0.95), ('land_day_1', int, 3, 2, 6), ('land_day_2', int, 6, 4, 9), ('land_day_3', int, 10, 7, 14), ('animal_buy_cutoff', int, 18, 12, 24), ('care_cutoff_day', int, 27, 22, 29), ('water_cutoff_day', int, 28, 24, 29), ('terminal_liquidation_day', int, 28, 24, 29), ('rf_WHEAT', float, 0.6, 0.2, 0.9), ('rf_CARROT', float, 0.55, 0.2, 0.9), ('rf_TOMATO', float, 0.6, 0.2, 0.9), ('rf_STRAWBERRY', float, 0.65, 0.2, 0.9), ('rf_MELON', float, 0.6, 0.2, 0.9), ('rf_FERTILIZER', float, 0.4, 0.1, 0.8), ('rf_EGG', float, 0.55, 0.2, 0.9), ('rf_MILK', float, 0.65, 0.2, 0.9), ('rf_WOOL', float, 0.65, 0.2, 0.9), ('cc_WHEAT', int, 25, 20, 28), ('cc_CARROT', int, 26, 20, 28), ('cc_TOMATO', int, 20, 15, 25), ('cc_STRAWBERRY', int, 18, 14, 24), ('cc_MELON', int, 18, 14, 24)]

def profile_to_vector(profile: StrategyProfile | None=None) -> list[float]:
    p = profile or DEFAULT_PROFILE
    vec: list[float] = []
    for name, ptype, default_val, min_val, max_val in PARAM_SPECS:
        if name.startswith('rf_'):
            key = name[3:]
            val = p.reserve_factors.get(key, default_val)
        elif name.startswith('cc_'):
            key = name[3:]
            val = p.crop_cutoffs.get(key, default_val)
        else:
            val = getattr(p, name, default_val)
        norm_val = 2.0 * (float(val) - min_val) / (max_val - min_val) - 1.0
        vec.append(float(norm_val))
    return vec

def vector_to_profile(vec: list[float] | Any) -> StrategyProfile:
    kwargs: dict[str, Any] = {}
    reserve_factors = dict(DEFAULT_PROFILE.reserve_factors)
    crop_cutoffs = dict(DEFAULT_PROFILE.crop_cutoffs)
    for i, (name, ptype, default_val, min_val, max_val) in enumerate(PARAM_SPECS):
        if i < len(vec):
            norm_val = float(vec[i])
            norm_val = max(-1.0, min(1.0, norm_val))
            unnorm_val = min_val + (norm_val + 1.0) / 2.0 * (max_val - min_val)
            val = int(round(unnorm_val)) if ptype is int else round(float(unnorm_val), 4)
        else:
            val = default_val
        if name.startswith('rf_'):
            reserve_factors[name[3:]] = float(val)
        elif name.startswith('cc_'):
            crop_cutoffs[name[3:]] = int(val)
        else:
            kwargs[name] = val
    kwargs['reserve_factors'] = reserve_factors
    kwargs['crop_cutoffs'] = crop_cutoffs
    return StrategyProfile(**kwargs)

class TelemetryTracker:

    def __init__(self) -> None:
        self.actions_by_type: dict[str, int] = {}
        self.idle_turns: int = 0
        self.revenue_by_product: dict[str, float] = {}
        self.missed_feeds: int = 0
        self.missed_waters: int = 0
        self.fallback_count: int = 0

    def record_action(self, action_name: str) -> None:
        self.actions_by_type[action_name] = self.actions_by_type.get(action_name, 0) + 1
        if action_name == 'PASS':
            self.idle_turns += 1

    def to_dict(self) -> dict[str, Any]:
        return {'actions_by_type': dict(self.actions_by_type), 'idle_turns': self.idle_turns, 'revenue_by_product': dict(self.revenue_by_product), 'missed_feeds': self.missed_feeds, 'missed_waters': self.missed_waters, 'fallback_count': self.fallback_count}
