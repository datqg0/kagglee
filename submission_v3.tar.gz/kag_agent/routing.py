"""Deterministic routing for a board without blocking collisions."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
try:
    from .models import Position
except (ImportError, ValueError):
    from models import Position

def step_toward(source: Position, target: Position) -> list[str]:
    sx, sy = source
    tx, ty = target
    dx = tx - sx
    dy = ty - sy
    if dx == 0 and dy == 0:
        return ['PASS']
    if abs(dx) >= abs(dy) and dx != 0:
        return ['EAST' if dx > 0 else 'WEST']
    if dy != 0:
        return ['SOUTH' if dy > 0 else 'NORTH']
    return ['EAST' if dx > 0 else 'WEST']
