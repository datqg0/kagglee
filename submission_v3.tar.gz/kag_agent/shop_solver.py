"""Dynamic portfolio solver exploiting town shop draws and market elasticity."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
import math
from typing import Any, Mapping
try:
    from .constants import MARKET_PARAMS, SHOPS
except (ImportError, ValueError):
    from constants import MARKET_PARAMS, SHOPS

def demand_counts(shops: Any) -> dict[str, int]:
    if hasattr(shops, 'shops'):
        shops = shops.shops
    if not isinstance(shops, (list, tuple)):
        shops = ()
    demand = {item: 0 for item in MARKET_PARAMS}
    for shop in shops:
        products = SHOPS.get(shop, ())
        multiplier = 2 if len(products) == 1 else 1
        for item in products:
            demand[item] += multiplier
    return demand

def daily_town_demand(shops: Any, item: str) -> float:
    centre = 0.0 if item == 'FERTILIZER' else 1.0
    return centre + 6.0 * demand_counts(shops).get(item, 0)

def compute_opening_portfolio(shops: tuple[str, ...]) -> dict[str, dict[str, int]]:
    demand = demand_counts(shops)
    egg_demand = demand.get('EGG', 0)
    milk_demand = demand.get('MILK', 0)
    wool_demand = demand.get('WOOL', 0)
    strawberry_demand = demand.get('STRAWBERRY', 0)
    tomato_demand = demand.get('TOMATO', 0)
    carrot_demand = demand.get('CARROT', 0)
    animal_buys = {'GOOSE': 0, 'COW': 3, 'SHEEP': 2}
    seed_buys = {'WHEAT': 9, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 5}
    if wool_demand >= 2:
        animal_buys = {'GOOSE': 0, 'COW': 2, 'SHEEP': 3}
        seed_buys = {'WHEAT': 10, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 5}
    elif milk_demand >= 2:
        animal_buys = {'GOOSE': 0, 'COW': 4, 'SHEEP': 1}
        seed_buys = {'WHEAT': 9, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 5}
    elif egg_demand >= 2 and milk_demand == 0:
        animal_buys = {'GOOSE': 2, 'COW': 2, 'SHEEP': 1}
        seed_buys = {'WHEAT': 11, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 4}
    elif strawberry_demand >= 2:
        animal_buys = {'GOOSE': 0, 'COW': 3, 'SHEEP': 2}
        seed_buys = {'WHEAT': 8, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 3, 'MELON': 4}
    elif carrot_demand >= 2 and tomato_demand == 0:
        animal_buys = {'GOOSE': 0, 'COW': 3, 'SHEEP': 2}
        seed_buys = {'WHEAT': 9, 'CARROT': 4, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 3}
    return {'animal_buys': animal_buys, 'seed_buys': seed_buys}
