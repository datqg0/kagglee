"""Turn-level task generation with explicit survival and endgame priorities."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
try:
    from .access import as_int, getv
except (ImportError, ValueError):
    from access import as_int, getv
try:
    from .constants import ANIMALS, CROPS, PRODUCTS
except (ImportError, ValueError):
    from constants import ANIMALS, CROPS, PRODUCTS
try:
    from .models import EconomicPlan, Position, Task
except (ImportError, ValueError):
    from models import EconomicPlan, Position, Task
try:
    from .world import WorldState, manhattan
except (ImportError, ValueError):
    from world import WorldState, manhattan

def _stable(kind: str, position: Position, suffix: str='') -> str:
    return f'{kind}:{position[0]}:{position[1]}:{suffix}'

def _build_positions(world: WorldState, quantity: int, excluded: set[Position]) -> list[Position]:
    center = (world.board_size // 2 - 1, world.board_size // 2 - 1)
    candidates = [position for position in world.empty_tiles if position not in excluded]
    candidates.sort(key=lambda p: (manhattan(p, center), p[1], p[0]))
    return candidates[:max(0, quantity)]

def _fertilizer_has_future_value(world: WorldState, tile: object, crop: str) -> bool:
    data = CROPS[crop]
    planted = as_int(getv(tile, 'planted_day', world.day), world.day)
    age = world.day - planted
    if not bool(data['ongoing']):
        window_start = (int(data['max_yield_day']) + 1) // 2
        return any((window_start <= age + offset <= int(data['max_yield_day']) for offset in range(3)))
    for offset in range(3):
        next_day = world.day + offset + 1
        since_first = next_day - planted - int(data['first_yield_day'])
        if since_first < 0 or since_first % int(data['interval']) != 0:
            continue
        production_count = since_first // int(data['interval']) + 1
        if production_count <= int(data['max_yield']):
            return True
    return False

def generate_tasks(world: WorldState, plan: EconomicPlan) -> list[Task]:
    tasks: list[Task] = []
    reserved_tiles: set[Position] = set()
    endgame = world.day >= 29
    turns_left_today = max(0, 22 - world.hour + 1) if endgame else 24 - world.hour
    empty_by_structure: dict[str, list[Position]] = {'COOP': [], 'PASTURE': []}
    for located in world.empty_structures:
        kind = str(getv(located.tile, 'kind', ''))
        if kind in empty_by_structure:
            empty_by_structure[kind].append(located.position)
    for positions in empty_by_structure.values():
        positions.sort(key=lambda p: (manhattan(p, world.nearest_shed_access(p)), p[1], p[0]))
    carried_by_animal = {animal: sum((unit.inventory.get(animal, 0) for unit in world.units)) for animal in ANIMALS}
    for structure in ('PASTURE', 'COOP'):
        positions = list(empty_by_structure[structure])
        animals = [animal for animal in ANIMALS if ANIMALS[animal]['structure'] == structure]
        animal_queue: list[str] = []
        for animal in sorted(animals, key=lambda name: (-carried_by_animal[name], name)):
            animal_queue.extend([animal] * carried_by_animal[animal])
        for position, animal in zip(positions, animal_queue):
            tasks.append(Task('PLACE_ANIMAL', position, priority=2, deadline=world.step + turns_left_today, value=500.0, item=animal, stable_id=_stable('PLACE', position, animal)))
    occupied_structures = {'COOP': 0, 'PASTURE': 0}
    for located in world.animals:
        kind = str(getv(located.tile, 'kind', ''))
        if kind in occupied_structures:
            occupied_structures[kind] += 1
    planned_pending = {animal: world.inventory_total(animal) + plan.animal_buys.get(animal, 0) for animal in ANIMALS}
    for structure in ('PASTURE', 'COOP'):
        pending = sum((planned_pending[animal] for animal in ANIMALS if ANIMALS[animal]['structure'] == structure))
        missing = max(0, pending - len(empty_by_structure[structure]))
        build_positions = _build_positions(world, missing, reserved_tiles)
        for position in build_positions:
            reserved_tiles.add(position)
            tasks.append(Task(f'BUILD_{structure}', position, priority=7, deadline=world.step + turns_left_today, value=350.0, stable_id=_stable(f'BUILD_{structure}', position)))
            empty_by_structure[structure].append(position)
    shed_target = world.nearest_shed_access(world.units[0].position)
    for animal in ANIMALS:
        matching = str(ANIMALS[animal]['structure'])
        available = min(world.shed.get(animal, 0), len(empty_by_structure[matching]))
        for index in range(available):
            tasks.append(Task('PICKUP_ANIMAL', shed_target, priority=5, deadline=world.step + turns_left_today, value=450.0, item=animal, quantity=1, stable_id=_stable('PICKUP_ANIMAL', shed_target, f'{animal}:{index}')))
    if endgame:
        for unit in world.units:
            carried_products = sum((unit.inventory.get(item, 0) for item in PRODUCTS))
            if carried_products <= 0:
                continue
            distance = manhattan(unit.position, world.nearest_shed_access(unit.position))
            tasks.append(Task('DROP', world.nearest_shed_access(unit.position), priority=0, deadline=world.step + max(0, turns_left_today - 1), value=10000.0 + distance, stable_id=f'DROP:{unit.index}'))
    if not endgame:
        unfed = []
        for located in world.animals:
            tile = located.tile
            if not bool(getv(tile, 'fed_today', False)):
                unfed.append(located)
                urgency = 3 if world.hour >= 15 or as_int(getv(tile, 'consecutive_unfed', 0)) >= 1 else 14
                tasks.append(Task('FEED', located.position, priority=urgency, deadline=(world.day + 1) * 24 - 1, value=900.0, item='WHEAT', stable_id=_stable('FEED', located.position)))
        carried_wheat = sum((unit.inventory.get('WHEAT', 0) for unit in world.units))
        required_pickup = max(0, len(unfed) - carried_wheat)
        wheat_available = world.shed.get('WHEAT', 0)
        pickup_quantity = min(required_pickup, wheat_available)
        pickup_index = 0
        while pickup_quantity > 0 and pickup_index < len(world.units):
            quantity = min(6, pickup_quantity)
            tasks.append(Task('PICKUP_WHEAT', shed_target, priority=4 if world.hour >= 12 else 12, deadline=(world.day + 1) * 24 - 1, value=700.0, item='WHEAT', quantity=quantity, stable_id=_stable('PICKUP_WHEAT', shed_target, str(pickup_index))))
            pickup_quantity -= quantity
            pickup_index += 1
        for located in world.plants:
            tile = located.tile
            if not bool(getv(tile, 'watered_today', False)):
                urgency = 2 if world.hour >= 16 or as_int(getv(tile, 'consecutive_unwatered', 0)) >= 1 else 16
                tasks.append(Task('WATER', located.position, priority=urgency, deadline=(world.day + 1) * 24 - 1, value=850.0, stable_id=_stable('WATER', located.position)))
    for located in world.plants:
        tile = located.tile
        crop = str(getv(tile, 'crop', ''))
        yield_units = as_int(getv(tile, 'yield_units', 0))
        age = world.day - as_int(getv(tile, 'planted_day', world.day))
        if crop not in CROPS or yield_units <= 0 or age < CROPS[crop]['first_yield_day']:
            continue
        if endgame:
            distance = manhattan(located.position, world.nearest_shed_access(located.position))
            if distance + 2 > max(0, 23 - world.hour):
                continue
        priority = 4 if endgame else 9 if yield_units >= CROPS[crop]['max_yield'] else 25
        tasks.append(Task('HARVEST', located.position, priority=priority, deadline=world.step + max(0, turns_left_today - 2), value=float(yield_units * 100), item=crop, stable_id=_stable('HARVEST_PLANT', located.position)))
    for located in world.animals:
        tile = located.tile
        animal = str(getv(tile, 'animal', ''))
        yield_units = as_int(getv(tile, 'yield_units', 0))
        if animal not in ANIMALS or yield_units <= 0:
            continue
        if endgame:
            distance = manhattan(located.position, world.nearest_shed_access(located.position))
            if distance + 2 > max(0, 23 - world.hour):
                continue
        near_cap = yield_units >= int(ANIMALS[animal]['max_held']) - 1
        priority = 3 if endgame else 8 if near_cap else 24
        tasks.append(Task('HARVEST', located.position, priority=priority, deadline=world.step + max(0, turns_left_today - 2), value=float(yield_units * 120), item=str(ANIMALS[animal]['product']), stable_id=_stable('HARVEST_ANIMAL', located.position)))
    if world.day <= 28:
        fertilizer_price = world.market_prices.get('FERTILIZER', 0)
        fertilizer_priority = 30 if fertilizer_price >= 60 else 55 if fertilizer_price >= 20 else 88
        for located in world.animals:
            if bool(getv(located.tile, 'fertilizer_available', False)):
                tasks.append(Task('COLLECT_FERTILIZER', located.position, priority=fertilizer_priority, deadline=world.step + turns_left_today, value=100.0, item='FERTILIZER', stable_id=_stable('COLLECT_FERTILIZER', located.position)))
    if world.day <= 27:
        for located in world.animals:
            tile = located.tile
            if bool(getv(tile, 'fed_today', False)) and (not bool(getv(tile, 'cared_today', False))):
                tasks.append(Task('CARE', located.position, priority=15, deadline=(world.day + 1) * 24 - 1, value=85.0, stable_id=_stable('CARE', located.position)))
        carried_fertilizer = sum((unit.inventory.get('FERTILIZER', 0) for unit in world.units))
        fertilizable = []
        unlocked = len(world.unlocked_quadrants)
        saving_for_land = unlocked == 1 and world.day >= 2 or (unlocked == 2 and world.day >= 5)
        for located in world.plants if not saving_for_land else ():
            tile = located.tile
            crop = str(getv(tile, 'crop', ''))
            fertilized_until = as_int(getv(tile, 'fertilized_until_day', -1), -1)
            age = world.day - as_int(getv(tile, 'planted_day', world.day))
            if crop in CROPS and fertilized_until < world.day and (age <= CROPS[crop]['max_yield_day']) and _fertilizer_has_future_value(world, tile, crop):
                fertilizable.append(located)
                tasks.append(Task('FERTILIZE', located.position, priority=43, deadline=world.step + turns_left_today, value=70.0, item='FERTILIZER', stable_id=_stable('FERTILIZE', located.position)))
        if carried_fertilizer == 0 and fertilizable and (world.shed.get('FERTILIZER', 0) > 0):
            quantity = min(4, world.shed.get('FERTILIZER', 0), len(fertilizable))
            tasks.append(Task('PICKUP_FERTILIZER', shed_target, priority=36, deadline=world.step + turns_left_today, value=80.0, item='FERTILIZER', quantity=quantity, stable_id=_stable('PICKUP_FERTILIZER', shed_target)))
    if world.day <= 26 and world.hour <= 22:
        action_slots = 24 - world.hour
        plantable = [position for position in world.empty_tiles if position not in reserved_tiles and min((manhattan(unit.position, position) for unit in world.units)) + 2 <= action_slots]
        center = (world.board_size // 2 - 1, world.board_size // 2 - 1)
        plantable.sort(key=lambda p: (manhattan(p, center), p[1], p[0]))
        cursor = 0
        for crop in sorted(CROPS, key=lambda name: (CROPS[name]['first_yield_day'], name)):
            quantity = min(world.seeds.get(crop, 0), max(0, plan.crop_targets.get(crop, 0) - world.crop_count(crop, False)))
            for index in range(quantity):
                if cursor >= len(plantable):
                    break
                position = plantable[cursor]
                cursor += 1
                reserved_tiles.add(position)
                tasks.append(Task('PLANT', position, priority=18 if world.day == 0 else 32, deadline=(world.day + 1) * 24 - 2, value=50.0, item=crop, stable_id=_stable('PLANT', position, f'{crop}:{index}')))
    weed_priority = 46 if len(world.empty_tiles) < 4 else 72
    for located in world.weeds:
        tasks.append(Task('DIG', located.position, priority=weed_priority, deadline=world.step + 96, value=20.0, stable_id=_stable('DIG', located.position)))
    if not endgame:
        for unit in world.units:
            carried_products = sum((unit.inventory.get(item, 0) for item in PRODUCTS))
            if carried_products >= 8 or (world.money < 150 and carried_products > 0):
                tasks.append(Task('DROP', world.nearest_shed_access(unit.position), priority=34, deadline=world.step + turns_left_today, value=float(carried_products * 20), stable_id=f'DROP:{unit.index}'))
    tasks.sort(key=lambda task: (task.priority, task.deadline, -task.value, task.stable_id))
    return tasks[:192]
