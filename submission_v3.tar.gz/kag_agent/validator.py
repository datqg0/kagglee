"""Final action-boundary validation and resource oversubscription guards."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
try:
    from .constants import ANIMALS, CROPS, MARKET_OPS, MAX_MARKET_ORDERS, PRODUCTS, UNIT_OPS
except (ImportError, ValueError):
    from constants import ANIMALS, CROPS, MARKET_OPS, MAX_MARKET_ORDERS, PRODUCTS, UNIT_OPS
try:
    from .world import WorldState
except (ImportError, ValueError):
    from world import WorldState

def _normalize_unit_action(action: object) -> list:
    if not isinstance(action, list) or not action or action[0] not in UNIT_OPS:
        return ['PASS']
    op = action[0]
    if op == 'PLANT':
        return ['PLANT', action[1]] if len(action) >= 2 and action[1] in CROPS else ['PASS']
    if op in {'PICKUP', 'PLACE'}:
        if len(action) < 2 or action[1] not in {*PRODUCTS, *ANIMALS}:
            return ['PASS']
        if len(action) < 3:
            return [op, action[1]]
        try:
            quantity = int(action[2])
        except (TypeError, ValueError, OverflowError):
            return ['PASS']
        return [op, action[1], quantity] if quantity > 0 else ['PASS']
    return [op]

def _normalize_market_order(order: object) -> list | None:
    if not isinstance(order, list) or not order or order[0] not in MARKET_OPS:
        return None
    op = order[0]
    if op in {'HIRE', 'BUY_LAND'}:
        return [op]
    if len(order) < 3:
        return None
    item = order[1]
    valid_item = op == 'BUY_SEED' and item in CROPS or (op == 'BUY_PRODUCT' and item in {'WHEAT', 'FERTILIZER'}) or (op == 'BUY_ANIMAL' and item in ANIMALS) or (op == 'SELL' and item in PRODUCTS)
    if not valid_item:
        return None
    try:
        quantity = int(order[2])
    except (TypeError, ValueError, OverflowError):
        return None
    if quantity <= 0:
        return None
    return [op, item, quantity]

def validate_action(world: WorldState, unit_actions: list[list], market_orders: list[list]) -> dict:
    expected_units = len(world.units)
    normalized = [_normalize_unit_action(action) for action in unit_actions[:expected_units]]
    while len(normalized) < expected_units:
        normalized.append(['PASS'])
    used_seeds = {crop: 0 for crop in CROPS}
    for index, action in enumerate(normalized):
        if action[0] != 'PLANT' or len(action) < 2:
            continue
        crop = action[1]
        if crop not in CROPS or used_seeds[crop] >= world.seeds.get(crop, 0):
            normalized[index] = ['PASS']
        else:
            used_seeds[crop] += 1
    market: list[list] = []
    for order in market_orders:
        normalized_order = _normalize_market_order(order)
        if normalized_order is not None:
            market.append(normalized_order)
        if len(market) >= MAX_MARKET_ORDERS:
            break
    return {'farmer': normalized[0] if normalized else ['PASS'], 'hands': normalized[1:], 'market': market}
