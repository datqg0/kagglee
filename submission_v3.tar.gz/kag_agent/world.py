"""Observation parsing and compact read-only world model."""
from __future__ import annotations
import os
import sys
_cur = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
if _cur not in sys.path:
    sys.path.insert(0, _cur)
_parent = os.path.dirname(_cur)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
from dataclasses import dataclass
from typing import Any
try:
    from .access import as_float, as_int, count_of, getv
except (ImportError, ValueError):
    from access import as_float, as_int, count_of, getv
try:
    from .constants import ANIMALS, CROPS, EPISODE_STEPS, PRODUCTS, TURNS_PER_DAY
except (ImportError, ValueError):
    from constants import ANIMALS, CROPS, EPISODE_STEPS, PRODUCTS, TURNS_PER_DAY
try:
    from .models import LocatedTile, Position, UnitState
except (ImportError, ValueError):
    from models import LocatedTile, Position, UnitState

def _mapping_counts(value: Any, keys: tuple[str, ...] | list[str]) -> dict[str, int]:
    return {key: count_of(value, key) for key in keys}

@dataclass(slots=True)
class WorldState:
    raw_obs: Any
    player: int
    opponent: int
    day: int
    hour: int
    step: int
    remaining_steps: int
    board_size: int
    money: float
    opponent_money: float
    farm: Any
    opponent_farm: Any
    private: Any
    market: Any
    town: Any
    tiles: Any
    units: list[UnitState]
    plants: list[LocatedTile]
    animals: list[LocatedTile]
    weeds: list[LocatedTile]
    empty_tiles: list[Position]
    empty_structures: list[LocatedTile]
    locked_tiles: list[Position]
    shed: dict[str, int]
    seeds: dict[str, int]
    unlocked_quadrants: tuple[str, ...]
    hires_today: int
    market_inventory: dict[str, int]
    market_prices: dict[str, int]
    shops: tuple[str, ...]
    opponent_plants: dict[str, int]
    opponent_animals: dict[str, int]

    @classmethod
    def from_observation(cls, obs: Any) -> 'WorldState':
        farms = getv(obs, 'farms', []) or []
        player = as_int(getv(obs, 'player', 0), 0)
        if not farms or player < 0 or player >= len(farms):
            raise ValueError("observation does not contain the current player's farm")
        opponent = 1 - player if len(farms) >= 2 else player
        farm = farms[player]
        opponent_farm = farms[opponent]
        tiles = getv(farm, 'tiles', []) or []
        board_size = len(tiles)
        if board_size <= 0:
            raise ValueError('farm has no tile grid')
        day = as_int(getv(obs, 'day', 0), 0)
        hour = as_int(getv(obs, 'hour', 0), 0)
        step = as_int(getv(obs, 'step', day * TURNS_PER_DAY + hour), day * TURNS_PER_DAY + hour)
        private = getv(obs, 'private', {}) or {}
        market = getv(obs, 'market', {}) or {}
        town = getv(obs, 'town', {}) or {}
        hands = getv(farm, 'hands', []) or []
        positions = [getv(farm, 'farmer', [0, 0]), *hands]
        inventories = getv(private, 'inventories', []) or []
        units: list[UnitState] = []
        for index, pos in enumerate(positions):
            if not isinstance(pos, (list, tuple)) or len(pos) < 2:
                pos = [0, 0]
            inv = inventories[index] if index < len(inventories) else {}
            inv_counts = {key: count_of(inv, key) for key in (*PRODUCTS, *ANIMALS) if count_of(inv, key) > 0}
            units.append(UnitState(index=index, position=(as_int(pos[0]), as_int(pos[1])), inventory=inv_counts, is_hand=index > 0))
        plants: list[LocatedTile] = []
        animals: list[LocatedTile] = []
        weeds: list[LocatedTile] = []
        empty_tiles: list[Position] = []
        empty_structures: list[LocatedTile] = []
        locked_tiles: list[Position] = []
        for y, row in enumerate(tiles):
            for x, tile in enumerate(row):
                pos = (x, y)
                if tile is None:
                    empty_tiles.append(pos)
                elif tile == 'LOCKED':
                    locked_tiles.append(pos)
                elif getv(tile, 'kind', '') == 'PLANT':
                    plants.append(LocatedTile(pos, tile))
                elif getv(tile, 'kind', '') == 'WEED':
                    weeds.append(LocatedTile(pos, tile))
                elif getv(tile, 'animal', None) in ANIMALS:
                    animals.append(LocatedTile(pos, tile))
                elif getv(tile, 'kind', '') in ('COOP', 'PASTURE'):
                    empty_structures.append(LocatedTile(pos, tile))
        opponent_plants = {crop: 0 for crop in CROPS}
        opponent_animals = {animal: 0 for animal in ANIMALS}
        opponent_tiles = getv(opponent_farm, 'tiles', []) or []
        for row in opponent_tiles:
            for tile in row:
                crop = getv(tile, 'crop', '')
                animal = getv(tile, 'animal', '')
                if crop in opponent_plants:
                    opponent_plants[crop] += 1
                if animal in opponent_animals:
                    opponent_animals[animal] += 1
        shed_source = getv(private, 'shed', {}) or {}
        seed_source = getv(private, 'seeds', {}) or {}
        shed = _mapping_counts(shed_source, [*PRODUCTS, *ANIMALS])
        seeds = _mapping_counts(seed_source, list(CROPS))
        market_inventory = _mapping_counts(getv(market, 'inventory', {}) or {}, list(PRODUCTS))
        market_prices = _mapping_counts(getv(market, 'prices', {}) or {}, list(PRODUCTS))
        return cls(raw_obs=obs, player=player, opponent=opponent, day=day, hour=hour, step=step, remaining_steps=max(0, EPISODE_STEPS - step - 1), board_size=board_size, money=as_float(getv(farm, 'money', 0.0)), opponent_money=as_float(getv(opponent_farm, 'money', 0.0)), farm=farm, opponent_farm=opponent_farm, private=private, market=market, town=town, tiles=tiles, units=units, plants=plants, animals=animals, weeds=weeds, empty_tiles=empty_tiles, empty_structures=empty_structures, locked_tiles=locked_tiles, shed=shed, seeds=seeds, unlocked_quadrants=tuple(getv(farm, 'unlocked_quadrants', ['NW']) or ['NW']), hires_today=as_int(getv(farm, 'hires_today', len(hands)), len(hands)), market_inventory=market_inventory, market_prices=market_prices, shops=tuple(getv(town, 'unlocked_shops', []) or []), opponent_plants=opponent_plants, opponent_animals=opponent_animals)

    @property
    def shed_load(self) -> int:
        return sum(self.shed.values())

    @property
    def remaining_days(self) -> float:
        return self.remaining_steps / float(TURNS_PER_DAY)

    def is_shed_access(self, position: Position) -> bool:
        half = self.board_size // 2
        return position in {(half - 1, half - 1), (half, half - 1), (half - 1, half), (half, half)}

    def nearest_shed_access(self, position: Position) -> Position:
        half = self.board_size // 2
        candidates = ((half - 1, half - 1), (half, half - 1), (half - 1, half), (half, half))
        return min(candidates, key=lambda p: (manhattan(position, p), p[1], p[0]))

    def tile_at(self, position: Position) -> Any:
        x, y = position
        if 0 <= y < self.board_size and 0 <= x < self.board_size:
            return self.tiles[y][x]
        return 'LOCKED'

    def inventory_total(self, item: str) -> int:
        return self.shed.get(item, 0) + sum((unit.inventory.get(item, 0) for unit in self.units))

    def animal_count(self, animal: str, include_pending: bool=True) -> int:
        placed = sum((1 for located in self.animals if getv(located.tile, 'animal', '') == animal))
        if not include_pending:
            return placed
        return placed + self.inventory_total(animal)

    def crop_count(self, crop: str, include_seeds: bool=True) -> int:
        planted = sum((1 for located in self.plants if getv(located.tile, 'crop', '') == crop))
        return planted + (self.seeds.get(crop, 0) if include_seeds else 0)

def manhattan(a: Position, b: Position) -> int:
    return abs(a[0] - b[0]) + abs(a[1] - b[1])
