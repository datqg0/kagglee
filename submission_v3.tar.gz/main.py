"""Antigravity V3 competition entry point."""
from __future__ import annotations

import os
import sys

_cur_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.path.abspath(os.getcwd())
if _cur_dir not in sys.path:
    sys.path.insert(0, _cur_dir)

for extra in ["/kaggle_simulations/agent", "."]:
    if os.path.exists(extra) and extra not in sys.path:
        sys.path.insert(0, extra)

from kag_agent.entrypoint import agent

__all__ = ["agent"]
